import { X } from 'lucide-react';

interface QRDisplayProps {
  invoice: string;
  amount: number;
  message: string;
  onClose: () => void;
}

export function QRDisplay({ invoice, amount, message, onClose }: QRDisplayProps) {
  return (
    <div className="w-full bg-white border-2 border-orange-500 rounded-lg p-6 shadow-xl animate-fadeIn">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Lightning Invoice</h3>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="bg-white p-4 rounded-lg border border-gray-200 mb-4">
        <div className="aspect-square bg-gradient-to-br from-orange-100 to-orange-50 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <div className="w-48 h-48 bg-white rounded-lg shadow-inner flex items-center justify-center mb-3">
              <p className="text-gray-400 text-sm px-4">QR Code will be generated here</p>
            </div>
            <p className="text-sm text-gray-500">Scan with Lightning wallet</p>
          </div>
        </div>
      </div>

      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-600">Amount:</span>
          <span className="font-semibold text-gray-800">{amount.toLocaleString()} sats</span>
        </div>
        {message && (
          <div className="flex justify-between">
            <span className="text-gray-600">Message:</span>
            <span className="font-medium text-gray-800 text-right max-w-[200px] truncate">
              {message}
            </span>
          </div>
        )}
      </div>

      <div className="mt-4 p-3 bg-gray-50 rounded-lg">
        <p className="text-xs text-gray-600 break-all font-mono">
          {invoice}
        </p>
      </div>
    </div>
  );
}
