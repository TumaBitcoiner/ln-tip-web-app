export const config = {
  name: "Satoshi Nakamoto",
  profileImage: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400",
  lightningAddress: "satoshi@getalby.com"
};
